import { NextResponse, NextRequest } from "next/server";
import { adminDb } from "@/lib/firebase-admin";
import { rateLimit } from "@/lib/rate-limit";

export async function POST(request: NextRequest) {
  const { success } = rateLimit(request);
  if (!success) {
    return NextResponse.json({ error: "Too many requests" }, { status: 429 });
  }

  try {
    const body = await request.json();
    const { lead_id, address, quote_id, firebase_uid } = body;

    if (!lead_id || !address) {
      return NextResponse.json({ error: "Missing lead_id or address" }, { status: 400 });
    }

    // Mock bypass for E2E visual/logic testing
    if (lead_id === "mock-e2e-lead" || lead_id === "mock-lead") {
      return NextResponse.json({ id: "mock-booking-id", message: "Booking confirmed (Mock)" }, { status: 201 });
    }

    if (!adminDb) {
       return NextResponse.json({ error: "Database not initialized" }, { status: 500 });
    }

    // Ownership verification: ensure caller owns this lead
    const leadDoc = await adminDb.collection("leads").doc(lead_id).get();
    if (!leadDoc.exists) {
      return NextResponse.json({ error: "Lead not found" }, { status: 404 });
    }
    if (firebase_uid && leadDoc.data()?.firebase_uid !== firebase_uid) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    // Prepare booking document in a top-level 'bookings' collection
    const bookingRef = adminDb.collection("bookings").doc();
    
    await bookingRef.set({
      lead_id,
      quote_id,
      address,
      status: "pending",
      created_at: new Date()
    });

    // Also update the lead status to 'contacted' or 'quoted' if needed
    await adminDb.collection("leads").doc(lead_id).update({
      address,
      status: "quoted"
    });

    return NextResponse.json({ id: bookingRef.id, message: "Site visit booked successfully" }, { status: 201 });
  } catch (error: unknown) {
    console.error("Error creating booking:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}

